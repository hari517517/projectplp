﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using IPL_MVC.Models;

namespace IPL_MVC.Controllers
{
    public class EmployeeController : Controller
    {
        Training_23Jan19_PuneEntities DB_Context = new Training_23Jan19_PuneEntities();
        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }

        //public ActionResult Login()
        //{
        //    return View();
        //}
        //[HttpPost]
        //public ActionResult Login(RegisterDetails_172476 Details)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        DB_Context.SaveChanges();
        //        return RedirectToAction("Index", "Employee");
        //    }
        //    return View();
        //}



        // Add team
        public ActionResult AddTeams()
        {
            return View();
        }

        //Creating

        [HttpPost]

        public ActionResult AddTeams(Team_172476 teams)
        {
            if (ModelState.IsValid)
            {
                DB_Context.Team_172476.Add(teams);

                DB_Context.SaveChanges();
                return RedirectToAction("Index", DB_Context.Team_172476.ToList());
            }
            return View();
        }




    }
}