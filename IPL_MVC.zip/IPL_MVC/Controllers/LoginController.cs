﻿using IPL_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IPL_MVC.Controllers
{
    public class LoginController : Controller
    {
        Training_23Jan19_PuneEntities DB_Context = new Training_23Jan19_PuneEntities();
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(RegisterDetails_172476 Details)
        {
            if (ModelState.IsValid)
            {
                //DB_Context.RegisterDetails_172476.Add(Details);
                DB_Context.SaveChanges();
                return RedirectToAction("Index", "Admin");
            }




            return View();
        }




    }
}