﻿using IPL_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IPL_MVC.Controllers
{
    public class RegisterController : Controller
    {
        Training_23Jan19_PuneEntities DB_Context = new Training_23Jan19_PuneEntities();
        public ActionResult Index()
        {
            return View();
        }
        // GET: Register
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(RegisterDetails_172476 Details)
        {
            if (ModelState.IsValid)
            {
                DB_Context.RegisterDetails_172476.Add(Details);
                DB_Context.SaveChanges();
                return RedirectToAction("Register", DB_Context.RegisterDetails_172476.ToList());
            }
            return View();

        }
    }
}