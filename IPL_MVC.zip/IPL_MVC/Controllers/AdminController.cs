﻿using IPL_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;

namespace IPL_MVC.Controllers
{
    public class AdminController : Controller
    {
        Training_23Jan19_PuneEntities DB_Context = new Training_23Jan19_PuneEntities();
        // GET: Admin
        public ActionResult Index()
        {
            return View(DB_Context.Roles_172476.ToList());
        }
       
        //public ActionResult User()
        //{
        //    return View();
        //}
        //[HttpPost]
        //public ActionResult User(Users_172476 user)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        DB_Context.Users_172476.Add(user);

        //        DB_Context.SaveChanges();
        //        return RedirectToAction("Index", DB_Context.Users_172476.ToList());
        //    }
        //    return View();
        //}





        // ROLES
        public ActionResult Roles()
        {
            return View();
        }

        //Creating

        [HttpPost]
     
        public ActionResult Roles(Roles_172476 roles)
        {
            if (ModelState.IsValid)
            {
                DB_Context.Roles_172476.Add(roles);
                
                DB_Context.SaveChanges();
                return RedirectToAction("Index", DB_Context.Roles_172476.ToList());
            }
            return View();
        }
        [HttpGet]
        public ActionResult Update(int id)
        {
            var up = (from d in DB_Context.Roles_172476 where d.RoleId ==id select d).FirstOrDefault();
            return View(up);
        }
        [HttpPost]
        public ActionResult Update(Roles_172476 roles)
        {
            Roles_172476 roleent = (from s in DB_Context.Roles_172476 where s.RoleId == roles.RoleId select s).SingleOrDefault();
            roleent.RoleName = roles.RoleName;
            DB_Context.SaveChanges();

            return RedirectToAction("Index", DB_Context.Roles_172476.ToList());

        }
      
        [HttpPost]
        public ActionResult SearchRole(int id)
        {
           
            var re = (from d in DB_Context.Roles_172476 where d.RoleId ==id select d).SingleOrDefault();
            return View(re);
        }
        public ActionResult Delete(int id)
        {
            Roles_172476 roles = DB_Context.Roles_172476.Find(id);
            DB_Context.Roles_172476.Remove(roles);
            DB_Context.SaveChanges();


            return RedirectToAction("Index", DB_Context.Roles_172476.ToList());
        }



        //public ActionResult Employee()
        //{
        //    return View();
        //}
        public ActionResult PlayerAdd()
        {
            return View();
        }
        [HttpPost]
        public ActionResult PlayerAdd(Player_172476 player)
        {
            if (ModelState.IsValid)
            {
                DB_Context.Player_172476.Add(player);

                DB_Context.SaveChanges();
                return RedirectToAction("Index1", DB_Context.Player_172476.ToList());
            }
            return View();
           
        }
        public ActionResult Index1()
        {
            return View(DB_Context.Player_172476.ToList());
        }


    }

}